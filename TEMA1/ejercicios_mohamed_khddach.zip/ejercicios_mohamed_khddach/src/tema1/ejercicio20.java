package tema1;

public class ejercicio20 {
    public static void main(String[] args) {
        // 20. Escriba usando variables las siguientes expresiones:

        // 5 * Math.pow(a,2) * Math.pow(b,3) + Math.sqrt(Math.pow(a,2) + Math.pow(b,2))
        // Math.sqrt(4 * a * Math.pow(b,2)) + Math.pow(a + b, 2)
        // ( Math.pow(a,3) * b ) / ( 2 * a * Math.pow(b,2) ) - Math.sqrt(12 * Math.pow(d,4));
    }
}
