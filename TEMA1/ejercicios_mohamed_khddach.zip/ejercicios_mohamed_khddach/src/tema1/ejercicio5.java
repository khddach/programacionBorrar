package tema1;

public class ejercicio5 {
    public static void main(String[] args) {
        // 5. Cumplimenta la siguiente tabla:
        /*
           Código : int a='a'; System.out.println(a); --> ¿Funciona? si -->  Salida --> 97
           Código : int PI=3.14; System.out.println(PI); --> ¿Funciona? no -->  Salida --> error: no se puede convertir double a int
           Código : double PI=3,14; System.out.println(PI); --> ¿Funciona? no -->  Salida --> error: sintaxis incorrecta
           Código : boolean adivina=(1==4); System.out.println(adivina); --> ¿Funciona? si -->  Salida --> false
           Código : boolean adivina=(97=='a'==97); --> ¿Funciona? no -->  Salida --> error: no se puede comparar int con boolean
           Código : boolean adivina=(97=='a'==true); --> ¿Funciona? si -->  Salida --> el código funciona pero no es un método válido.
        */



        int a='a'; System.out.println(a);
        boolean adivina=(1==4); System.out.println(adivina);
    }
}
