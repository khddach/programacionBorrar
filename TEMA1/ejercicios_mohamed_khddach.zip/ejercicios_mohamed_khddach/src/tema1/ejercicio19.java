package tema1;

public class ejercicio19 {
    public static void main(String[] args) {
        // 19. Escriba el valor ASCII de la 'J' y de la 'j' sin consultar la tabla.

        int letra = 'J' ;
        System.out.println("J valor ASCII es : " + letra); // 74

        letra = 'j' ;
        System.out.println("j valor ASCII es : " + letra); // 106
    }
}
