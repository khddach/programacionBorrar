package tema1;

public class ejercicio3 {
    public static void main(String[] args) {

        /*
        3. Expresar las siguientes expresiones como condiciones lógicas.
        a. a es mayor que 2
        b. b es menor o igual que 25 pero mayor que 5
        c. c es mayor que 6 o igual a d
        d. e es par menor que 50
        e. f es mayor que a, b y c
        f. g es igual a 3, 4 ó 5

         a. --> a > 2
         b.  --> b <= 25 && b > 5
         c.  --> c > 6 || c == d
         d.  e % 2 == 0 && e < 50
         e.  f > a && f > b && f > c
         f.  g == 3 ||  g == 4  ||  g == 5
         */

    }
}
