package tema1;

public class ejercicio18 {
    public static void main(String[] args) {
        // 18. ¿Qué resultados se obtienen al realizar las operaciones siguientes? Si hay errores en la compilación,
        //corríjalos y dé una explicación de por qué suceden.
        //int a = 10, b = 3 , e = 1, d, e; --> error: variable e duplicada.
        //float x, y;
        //x= a / b; --> las variables a y b no están inicializada.
        //c = a < b && c; --> variable c es boolean y no declarada y  así que cambio lógica
        //d = a + b++;
        //e = ++a – b; -->
        //y = (float)a / b;

        int a = 10, b = 3 , e = 1, d;
        boolean c = true;
        float x, y;
        x= a / b;
        c = a < b && c;
        d = a + b++;
        e = ++a - b;
        y = (float) a / b;
    }
}
