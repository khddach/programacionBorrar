package tema1;

public class ejercicio4 {
    public static void main(String[] args) {
       /*
       4. Decir si son verdaderas o falsas las siguientes expresiones:
        a. (3 <= 7) && (7 <= 7)
        b. !((-8 > 1) && (3 <= 4))
        c. "Hola" == "Hola "
        d. ((2 ≤ 5) && (3 ≥ 6)) || (2 > -1)
        e. ((2 ≤ 5) || (3 ≥ 6)) && (2 > -1)
        */

        /*
         a. -->  true && true --> true
         b. -->  !(false && true) --> !false --> true
         c. -->  false
         d. -->  (true && false) || true --> true
         d. -->  ( (true) || (false) ) && true --> true

        */
    }
}
